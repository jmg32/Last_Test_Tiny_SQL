﻿namespace Entities
{
    public enum OperationStatus
    {
        Success,
        Error,
        Warning
    }
}
